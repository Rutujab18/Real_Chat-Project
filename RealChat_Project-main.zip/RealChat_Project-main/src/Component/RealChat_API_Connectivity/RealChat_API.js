// import React from "react";
// import axios from "axios";

// // Define the API BASE URL path for the API connectivity
// const REST_API_BASE_URL = "http://localhost:8081/Real-Chat/";
// // Code for get the data from the backend database
// export const registerData =()=> axios.post(REST_API_BASE_URL);