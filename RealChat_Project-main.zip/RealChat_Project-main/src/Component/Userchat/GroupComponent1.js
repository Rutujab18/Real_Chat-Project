import "./GroupComponent1.css";

const GroupComponent1 = (props) => {
  return (
    <div className="rectangle-parent5">
      <div className="frame-child12" />
      <div className="ellipse-frame">
        <img
          className="frame-child13"
          loading="lazy"
          alt=""
          src="/ellipse-5@2x.png"
        />
      </div>
      <div className="dank-helping-parent">
        <h3 className="dank-helping">dank helping</h3>
        <div className="edit-your-profile-wrapper">
          <i className="edit-your-profile">Edit your profile</i>
        </div>
      </div>
    </div>
  );
};

export default GroupComponent1;
