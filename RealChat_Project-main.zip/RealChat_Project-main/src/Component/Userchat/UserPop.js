import React from "react";
import { Fragment } from "react";
import './UserPop.css';

const UserPop =(props)=>{
    return(
        <Fragment>
            <div className="userMain">Hellow</div>
        </Fragment>
    )
}

export default UserPop;